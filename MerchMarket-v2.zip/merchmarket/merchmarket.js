/* ========================================
   MERCHMARKET — MASTER JS v2.0
   All functions implemented and wired up.
   ======================================== */

/* ─── 1. SHARED UTILITIES ─────────────────────────────────────── */

function saveLocal(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function loadLocal(key, fallback = []) {
  try { return JSON.parse(localStorage.getItem(key)) || fallback; }
  catch { return fallback; }
}

function debounce(fn, delay) {
  let t;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), delay);
  };
}

/* Toast – creates the element if the page doesn't have one */
function showToast(msg, type = 'default') {
  let toast = document.getElementById('mm-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'mm-toast';
    toast.style.cssText = `
      position:fixed;bottom:2rem;right:2rem;z-index:9999;
      padding:.9rem 1.6rem;border-radius:12px;font-weight:600;
      font-family:'DM Sans',sans-serif;font-size:.95rem;
      background:#1e1e1e;border:1px solid rgba(170,111,2,.5);
      color:#ffd8b5;transform:translateY(120%);
      transition:transform .35s cubic-bezier(.4,0,.2,1);
      display:flex;align-items:center;gap:.6rem;max-width:360px;
    `;
    document.body.appendChild(toast);
  }
  const icons = { success: '✅', error: '⚠️', info: 'ℹ️', default: '📢' };
  toast.innerHTML = `<span>${icons[type] || icons.default}</span><span>${msg}</span>`;
  toast.style.transform = 'translateY(0)';
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { toast.style.transform = 'translateY(120%)'; }, 4000);
}

/* ─── 2. AUTH & USER MANAGEMENT ──────────────────────────────── */

let users = loadLocal('merchUsers', []);

function createAccount(type, name, email, password) {
  if (!type || !name || !email || !password) {
    showToast('Please fill in all fields.', 'error'); return null;
  }
  if (users.find(u => u.email === email)) {
    showToast('An account with that email already exists.', 'error'); return null;
  }
  const user = {
    id: Date.now(),
    type,          // 'member' | 'brand'
    name,
    email,
    password,      // ⚠ plain-text — hash before production
    createdAt: new Date().toISOString(),
    orders: [],
    profile: { avatar: '' }
  };
  users.push(user);
  saveLocal('merchUsers', users);
  showToast(`Welcome, ${name}! Account created.`, 'success');
  return user;
}

function login(email, password) {
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) { showToast('Invalid email or password.', 'error'); return null; }
  saveLocal('currentUserId', user.id);
  showToast(`Welcome back, ${user.name}!`, 'success');
  setTimeout(() => {
    window.location.href = user.type === 'brand' ? 'brandflow.html' : 'marketplace.html';
  }, 800);
  return user;
}

function logout() {
  localStorage.removeItem('currentUserId');
  window.location.href = 'index.html';
}

function getCurrentUser() {
  const id = loadLocal('currentUserId', null);
  return users.find(u => u.id == id) || null;
}

/* ─── 3. CART SYSTEM ──────────────────────────────────────────── */

let cart = loadLocal('merchCart', []);

function getCartCount() {
  return cart.reduce((s, i) => s + i.quantity, 0);
}

function updateCartBadge() {
  const count = getCartCount();
  document.querySelectorAll('.cart-count, .cart-badge, #cart-count').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'inline-block' : 'none';
  });
}

/* Called from marketplace "Add to Cart" buttons */
function addToCart(btn) {
  const card  = btn.closest('.product-card');
  const title = card.querySelector('.product-title')?.textContent.trim() || 'Item';
  const priceRaw = card.querySelector('.product-price')?.textContent.trim() || '$0';
  const price = parseFloat(priceRaw.replace(/[^0-9.]/g, '')) || 0;
  const seller = card.querySelector('.seller-name')?.textContent.trim() || 'MerchMarket';
  const gradient = card.querySelector('.product-image')?.style.background || '';
  const id = 'static-' + title.toLowerCase().replace(/\s+/g, '-');

  const existing = cart.find(i => i.id === id);
  if (existing) {
    existing.quantity++;
  } else {
    cart.push({ id, name: title, price, seller, quantity: 1, gradient });
  }
  saveLocal('merchCart', cart);
  updateCartBadge();
  showToast(`${title} added to cart!`, 'success');
}

/* Called from inventory items */
function addToCartById(itemId) {
  const inv = loadLocal('merchInventory', []);
  const item = inv.find(i => i.id == itemId);
  if (!item) return;
  const existing = cart.find(c => c.id === 'inv-' + itemId);
  if (existing) { existing.quantity++; }
  else { cart.push({ id: 'inv-' + itemId, name: item.name, price: item.price, seller: 'Brand', quantity: 1, gradient: '' }); }
  saveLocal('merchCart', cart);
  updateCartBadge();
  showToast(`${item.name} added to cart!`, 'success');
}

/* ─── 4. MARKETPLACE ──────────────────────────────────────────── */

/* Static product catalogue (matches what's hard-coded in marketplace.html) */
const STATIC_PRODUCTS = [
  { id: 'p1', name: 'Abstract Wave T-Shirt', price: 28.99, seller: 'Creative Brand Co.', category: 'tshirts', tags: ['trending', 'wave', 'abstract'], gradient: 'linear-gradient(135deg,#667eea,#764ba2)', badge: 'Trending' },
  { id: 'p2', name: 'Minimal Logo Hoodie',   price: 49.99, seller: 'Streetwear Studio',  category: 'hoodies', tags: ['minimal', 'logo'], gradient: 'linear-gradient(135deg,#f093fb,#f5576c)', badge: 'New' },
  { id: 'p3', name: 'Retro Pattern Cap',     price: 22.99, seller: 'Retro Vibes',         category: 'caps',    tags: ['retro', 'pattern'], gradient: 'linear-gradient(135deg,#4facfe,#00f2fe)', badge: '' },
  { id: 'p4', name: 'Artistic Mug',          price: 18.99, seller: 'Designer Collective', category: 'mugs',    tags: ['limited', 'art'], gradient: 'linear-gradient(135deg,#fa709a,#fee140)', badge: 'Limited' },
  { id: 'p5', name: 'Nature Inspired Tee',   price: 32.99, seller: 'Eco Designs',         category: 'tshirts', tags: ['eco', 'nature', 'sustainable'], gradient: 'linear-gradient(135deg,#a8edea,#fed6e3)', badge: 'Eco' },
  { id: 'p6', name: 'Sunset Vibes Hoodie',   price: 45.99, seller: 'Beach Brand',         category: 'hoodies', tags: ['hot', 'sunset'], gradient: 'linear-gradient(135deg,#ffecd2,#fcb69f)', badge: 'Hot' },
  { id: 'p7', name: 'Canvas Tote Bag',       price: 24.99, seller: 'Artistic Threads',    category: 'bags',    tags: ['canvas', 'tote'], gradient: 'linear-gradient(135deg,#ff9a9e,#fecfef)', badge: '' },
  { id: 'p8', name: 'Street Culture Cap',    price: 19.99, seller: 'Urban Style',         category: 'caps',    tags: ['street', 'urban'], gradient: 'linear-gradient(135deg,#fddb92,#d1fdff)', badge: 'New' },
];

let currentProducts = [...STATIC_PRODUCTS];
let activeCategory  = 'all';
let activeSort      = 'featured';
let searchQuery     = '';

function initMarketplace() {
  // Merge any brand-uploaded inventory
  const inv = loadLocal('merchInventory', []);
  const dynProducts = inv.map(item => ({
    id: 'inv-' + item.id,
    name: item.name,
    price: item.price,
    seller: 'Brand',
    category: item.category || 'other',
    tags: item.tags || [],
    gradient: '',
    image: item.images?.[0] || null,
    badge: 'New'
  }));
  currentProducts = [...STATIC_PRODUCTS, ...dynProducts];
  applyFiltersAndSort();
}

function searchProducts() {
  searchQuery = document.getElementById('searchInput')?.value.trim().toLowerCase() || '';
  applyFiltersAndSort();
}

function filterProducts() {
  activeCategory = document.querySelector('.filters-section .filter-select')?.value || 'all';
  applyFiltersAndSort();
}

function sortProducts(value) {
  activeSort = value;
  applyFiltersAndSort();
}

function applyFiltersAndSort() {
  let list = [...currentProducts];

  if (searchQuery) {
    list = list.filter(p =>
      p.name.toLowerCase().includes(searchQuery) ||
      p.seller.toLowerCase().includes(searchQuery) ||
      p.tags.some(t => t.includes(searchQuery))
    );
  }

  if (activeCategory && activeCategory !== 'all') {
    list = list.filter(p => p.category === activeCategory);
  }

  if (activeSort === 'price-low')  list.sort((a, b) => a.price - b.price);
  if (activeSort === 'price-high') list.sort((a, b) => b.price - a.price);
  if (activeSort === 'newest')     list.reverse();

  const countEl = document.querySelector('.results-count strong');
  if (countEl) countEl.textContent = list.length;

  renderProductGrid(list);
}

function renderProductGrid(products) {
  const grid = document.querySelector('.product-grid');
  if (!grid) return;

  if (products.length === 0) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:4rem;color:#a0a0a0;">
      <div style="font-size:3rem;margin-bottom:1rem;">🔍</div>
      <p>No products found. Try a different search or filter.</p>
    </div>`;
    return;
  }

  grid.innerHTML = products.map(p => `
    <div class="product-card" data-category="${p.category}" data-id="${p.id}">
      <div class="product-image" style="background:${p.gradient || '#1e1e1e'}">
        ${p.image ? `<img src="${p.image}" style="width:100%;height:100%;object-fit:cover;">` : ''}
        ${p.badge ? `<div class="product-badge">${p.badge}</div>` : ''}
        <button class="wishlist-btn" onclick="toggleWishlist(this)">♡</button>
      </div>
      <div class="product-details">
        <div class="product-seller">
          <div class="seller-badge" style="background:${p.gradient || 'var(--gradient-1)'}"></div>
          <span class="seller-name">${p.seller}</span>
        </div>
        <h3 class="product-title">${p.name}</h3>
        <div class="product-rating">
          <span class="stars">⭐⭐⭐⭐⭐</span>
          <span class="rating-count">(${Math.floor(Math.random() * 200 + 20)})</span>
        </div>
        <div class="product-footer">
          <div class="product-price">$${p.price.toFixed(2)}</div>
          <button class="add-to-cart-btn" onclick="addToCart(this)">Add to Cart</button>
        </div>
      </div>
    </div>
  `).join('');
}

function toggleWishlist(btn) {
  btn.classList.toggle('active');
  btn.textContent = btn.classList.contains('active') ? '♥' : '♡';
  showToast(btn.classList.contains('active') ? 'Added to wishlist!' : 'Removed from wishlist', 'info');
}

function showSellModal() {
  const modal = document.getElementById('sellModal');
  if (modal) modal.classList.add('active');
}

function closeSellModal() {
  const modal = document.getElementById('sellModal');
  if (modal) modal.classList.remove('active');
}

function submitListing(e) {
  e.preventDefault();
  const form    = e.target;
  const inputs  = form.querySelectorAll('input,select,textarea');
  const name    = form.querySelector('input[placeholder*="Product Name"],input[placeholder*="Awesome"]')?.value.trim();
  const priceEl = form.querySelector('input[type="number"][placeholder="0.00"]');
  const price   = parseFloat(priceEl?.value) || 0;
  const catEl   = form.querySelector('select');
  const category = catEl?.value || 'other';
  const fileInput = document.getElementById('fileInput');

  if (!name || price <= 0) { showToast('Please fill in product name and price.', 'error'); return; }

  const inv = loadLocal('merchInventory', []);
  const newItem = {
    id: Date.now(),
    name,
    price,
    category,
    sku: 'MM-' + Date.now().toString(36).toUpperCase(),
    stock: parseInt(form.querySelector('input[placeholder="1"]')?.value) || 1,
    description: form.querySelector('textarea')?.value || '',
    tags: (form.querySelector('input[placeholder*="vintage"]')?.value || '').split(',').map(t => t.trim()).filter(Boolean),
    images: [],
    createdAt: new Date().toISOString()
  };

  inv.push(newItem);
  saveLocal('merchInventory', inv);
  closeSellModal();
  form.reset();
  showToast(`"${name}" listed successfully!`, 'success');
  initMarketplace(); // re-render to include new item
}

/* ─── 5. SOCIAL FEED ──────────────────────────────────────────── */

function filterFeed(category) {
  document.querySelectorAll('.filter-tab').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');

  document.querySelectorAll('.post-card').forEach(card => {
    const cat = card.dataset.category || 'all';
    const show = category === 'all' || cat === category || cat === 'all';
    card.style.display = show ? '' : 'none';
  });

  const visible = document.querySelectorAll('.post-card:not([style*="none"])').length;
  if (visible === 0) {
    let empty = document.getElementById('feedEmpty');
    if (!empty) {
      empty = document.createElement('div');
      empty.id = 'feedEmpty';
      empty.style.cssText = 'grid-column:1/-1;text-align:center;padding:4rem;color:#a0a0a0;';
      empty.innerHTML = '<div style="font-size:3rem">📭</div><p>Nothing here yet. Be the first to post!</p>';
      document.getElementById('feedGrid')?.appendChild(empty);
    }
  } else {
    document.getElementById('feedEmpty')?.remove();
  }
}

function toggleLike(el) {
  const countSpan = el.querySelector('.like-count');
  const isLiked   = el.classList.toggle('liked');
  if (!countSpan) return;
  const num = parseSocialCount(countSpan.textContent);
  countSpan.textContent = formatSocialCount(isLiked ? num + 1 : num - 1);
  el.style.color = isLiked ? '#ff3366' : '';
}

function toggleFollow(btn) {
  const isFollowing = btn.classList.toggle('following');
  btn.textContent = isFollowing ? 'Following' : 'Follow';
  btn.style.background = isFollowing ? 'rgba(196,125,46,.2)' : '';
  btn.style.borderColor = isFollowing ? '#c47d2e' : '';
  showToast(isFollowing ? 'You are now following this brand!' : 'Unfollowed.', isFollowing ? 'success' : 'info');
}

const _extraPosts = [
  { category: 'trending', gradient: 'linear-gradient(135deg,#a1c4fd,#c2e9fb)', brand: 'Neon Collective',  text: 'New drop: UV-reactive streetwear collection 🌟 Limited run — 50 units only.', tags: ['#neon','#uvprint','#limited'] },
  { category: 'new',      gradient: 'linear-gradient(135deg,#d4fc79,#96e6a1)', brand: 'GreenThread',      text: 'Bamboo-fiber tees, now with 12 new colour options 🌿 Soft, sustainable, stunning.', tags: ['#bamboo','#sustainable','#eco'] },
  { category: 'trending', gradient: 'linear-gradient(135deg,#f6d365,#fda085)', brand: 'Sunset Studio',    text: 'Our best-selling summer print just got a glow-up ☀️ Drop at midnight.', tags: ['#summer','#sunset','#print'] },
];
let _extraLoaded = 0;

function loadMore() {
  const grid = document.getElementById('feedGrid');
  if (!grid) return;
  if (_extraLoaded >= _extraPosts.length) {
    showToast("You've seen everything! Check back later.", 'info'); return;
  }
  const p = _extraPosts[_extraLoaded++];
  const card = document.createElement('div');
  card.className = 'post-card';
  card.dataset.category = p.category;
  card.innerHTML = `
    <div class="post-image" style="background:${p.gradient}">
      <div class="post-badge">🔥 New</div>
    </div>
    <div class="post-content">
      <div class="post-header">
        <div class="avatar" style="background:${p.gradient}"></div>
        <div class="post-info"><h4>${p.brand}</h4><span>Just now</span></div>
        <button class="follow-btn" onclick="toggleFollow(this)">Follow</button>
      </div>
      <p class="post-description">${p.text}</p>
      <div class="post-tags">${p.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
      <div class="post-stats">
        <span class="stat" onclick="toggleLike(this)">❤️ <span class="like-count">0</span></span>
        <span class="stat">💬 0</span><span class="stat">🔄 0</span>
        <span class="stat">🔖 Save</span>
      </div>
    </div>
  `;
  grid.appendChild(card);
  showToast('New posts loaded!', 'success');
}

/* social count helpers */
function parseSocialCount(str) {
  str = str.trim();
  if (str.endsWith('K')) return Math.round(parseFloat(str) * 1000);
  if (str.endsWith('M')) return Math.round(parseFloat(str) * 1000000);
  return parseInt(str) || 0;
}
function formatSocialCount(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000)    return (n / 1000).toFixed(1) + 'K';
  return String(n);
}

/* ─── 6. ADMIN DASHBOARD ──────────────────────────────────────── */

let adminOrders    = loadLocal('adminOrders', []);
let adminInventory = loadLocal('merchInventory', []);
let adminCustomers = loadLocal('adminCustomers', []);

function initAdmin() {
  /* Reload fresh data */
  adminOrders    = loadLocal('adminOrders', []);
  adminInventory = loadLocal('merchInventory', []);
  adminCustomers = loadLocal('adminCustomers', []);

  renderAll(); // ← was missing!

  /* Tab navigation */
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', e => {
      e.preventDefault();
      switchTab(tab.dataset.tab);
    });
  });

  /* Refresh button */
  document.getElementById('refresh-orders')?.addEventListener('click', () => {
    adminOrders = loadLocal('adminOrders', []);
    renderOrders();
    showToast('Orders refreshed.', 'success');
  });

  /* Add inventory */
  document.getElementById('add-inventory')?.addEventListener('click', () => showInventoryModal(null));

  /* Reset DB */
  document.getElementById('reset-db')?.addEventListener('click', confirmClearData);

  /* Order search */
  document.getElementById('orders-search')?.addEventListener('input',
    debounce(e => {
      const q = e.target.value.toLowerCase();
      const filtered = adminOrders.filter(o =>
        o.customer?.toLowerCase().includes(q) ||
        o.email?.toLowerCase().includes(q) ||
        String(o.id).includes(q)
      );
      renderOrders(filtered);
    }, 300)
  );
}

/* This was the missing function that crashed initAdmin */
function renderAll() {
  renderOrders();
  renderInventory();
  renderCustomers();
}

function switchTab(tabName) {
  document.querySelectorAll('.module').forEach(m => m.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  const section = document.getElementById(tabName);
  const tab     = document.querySelector(`[data-tab="${tabName}"]`);
  if (section) section.classList.add('active');
  if (tab)     tab.classList.add('active');

  if (tabName === 'orders')    renderOrders();
  if (tabName === 'inventory') renderInventory();
  if (tabName === 'customers') renderCustomers();
}

/* ── Orders ── */
function renderOrders(list = adminOrders) {
  const tbody = document.getElementById('orders-table-body');
  if (!tbody) return;

  const stats = { pending: 0, confirmed: 0, active: 0, completed: 0, cancelled: 0, revenue: 0 };
  list.forEach(o => {
    if (stats[o.status] !== undefined) stats[o.status]++;
    if (o.status !== 'cancelled') stats.revenue += (o.total || 0);
  });

  const safe = id => { const el = document.getElementById(id); if (el) el.textContent = stats[id.replace('-orders','')] ?? ''; };
  const rev  = document.getElementById('total-revenue');

  if (document.getElementById('total-orders'))     document.getElementById('total-orders').textContent     = list.length;
  if (document.getElementById('pending-orders'))   document.getElementById('pending-orders').textContent   = stats.pending;
  if (document.getElementById('confirmed-orders')) document.getElementById('confirmed-orders').textContent = stats.confirmed;
  if (document.getElementById('active-orders'))    document.getElementById('active-orders').textContent    = stats.active;
  if (document.getElementById('completed-orders')) document.getElementById('completed-orders').textContent = stats.completed;
  if (document.getElementById('cancelled-orders')) document.getElementById('cancelled-orders').textContent = stats.cancelled;
  if (rev) rev.textContent = '$' + stats.revenue.toFixed(2);

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:3rem;color:#a0a0a0;">No orders yet. They will appear here once customers start booking.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(o => `
    <tr>
      <td style="font-family:monospace;color:#ffd8b5;">#${o.id}</td>
      <td>${o.customer || '—'}</td>
      <td>${o.item || '—'}</td>
      <td style="font-size:.85rem;color:#a0a0a0;">${o.dates || '—'}</td>
      <td style="font-size:.85rem;">${o.location || '—'}</td>
      <td><strong>$${(o.total || 0).toFixed(2)}</strong></td>
      <td><span class="status ${o.status}">${o.status.toUpperCase()}</span></td>
      <td>
        <button class="action-btn" onclick="viewOrder('${o.id}')">View</button>
        ${o.status !== 'cancelled' && o.status !== 'completed'
          ? `<button class="action-btn" onclick="advanceOrderStatus('${o.id}')">Advance</button>
             <button class="action-btn" style="border-color:#f44336;color:#f44336;" onclick="cancelOrder('${o.id}')">Cancel</button>`
          : ''}
      </td>
    </tr>
  `).join('');
}

function advanceOrderStatus(id) {
  const flow = ['pending', 'confirmed', 'active', 'completed'];
  const o = adminOrders.find(x => x.id == id);
  if (!o) return;
  const idx = flow.indexOf(o.status);
  if (idx < flow.length - 1) {
    o.status = flow[idx + 1];
    saveLocal('adminOrders', adminOrders);
    renderOrders();
    showToast(`Order #${id} moved to "${o.status}".`, 'success');
  }
}

function cancelOrder(id) {
  if (!confirm(`Cancel order #${id}?`)) return;
  const o = adminOrders.find(x => x.id == id);
  if (o) { o.status = 'cancelled'; saveLocal('adminOrders', adminOrders); renderOrders(); showToast('Order cancelled.', 'info'); }
}

function viewOrder(id) {
  const o = adminOrders.find(x => x.id == id);
  if (!o) return;
  alert(`Order #${o.id}\nCustomer: ${o.customer}\nItem: ${o.item}\nTotal: $${(o.total||0).toFixed(2)}\nStatus: ${o.status}\nDates: ${o.dates}\nLocation: ${o.location}`);
}

/* ── Inventory ── */
function renderInventory() {
  const tbody = document.getElementById('inventory-table-body');
  if (!tbody) return;
  adminInventory = loadLocal('merchInventory', []);

  if (adminInventory.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:3rem;color:#a0a0a0;">No inventory items yet. Click "Add Item" to get started.</td></tr>`;
    return;
  }

  tbody.innerHTML = adminInventory.map(item => `
    <tr>
      <td><strong>${item.name}</strong></td>
      <td style="font-family:monospace;font-size:.85rem;color:#a0a0a0;">${item.sku || '—'}</td>
      <td>${item.stock ?? '—'}</td>
      <td><strong>$${(item.price || 0).toFixed(2)}</strong></td>
      <td>${item.images?.length || 0}</td>
      <td>
        <button class="action-btn" onclick="editInventory(${item.id})">Edit</button>
        <button class="action-btn" style="border-color:#f44336;color:#f44336;" onclick="deleteInventory(${item.id})">Delete</button>
      </td>
    </tr>
  `).join('');
}

function showInventoryModal(id) {
  const item = id ? adminInventory.find(i => i.id == id) : null;
  const modal = document.getElementById('inventory-modal');
  if (!modal) return;
  modal.classList.add('active');
  modal.innerHTML = `
    <div class="modal-content" onclick="event.stopPropagation()">
      <div class="modal-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;">
        <h2 style="color:#ffd8b5;font-family:'Syne',sans-serif;">${item ? 'Edit Item' : 'Add New Item'}</h2>
        <button onclick="closeInventoryModal()" style="background:none;border:none;color:#a0a0a0;font-size:1.5rem;cursor:pointer;">×</button>
      </div>
      <form id="inventoryForm" onsubmit="saveInventoryItem(event,${id || 'null'})">
        <div class="form-group">
          <label>Product Name *</label>
          <input type="text" id="inv-name" value="${item?.name || ''}" required placeholder="e.g. Custom Print T-Shirt">
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
          <div class="form-group">
            <label>Price ($) *</label>
            <input type="number" id="inv-price" value="${item?.price || ''}" step="0.01" min="0" required placeholder="0.00">
          </div>
          <div class="form-group">
            <label>Stock Quantity *</label>
            <input type="number" id="inv-stock" value="${item?.stock ?? ''}" min="0" required placeholder="0">
          </div>
        </div>
        <div class="form-group">
          <label>Category</label>
          <select id="inv-category">
            ${['tshirts','hoodies','caps','mugs','bags','other'].map(c =>
              `<option value="${c}" ${item?.category===c?'selected':''}>${c.charAt(0).toUpperCase()+c.slice(1)}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea id="inv-desc" rows="3" placeholder="Describe your product...">${item?.description || ''}</textarea>
        </div>
        <div class="form-group">
          <label>Tags (comma-separated)</label>
          <input type="text" id="inv-tags" value="${(item?.tags||[]).join(', ')}" placeholder="summer, custom, limited">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;padding:1rem;">
          ${item ? '💾 Save Changes' : '🚀 Add Item'}
        </button>
      </form>
    </div>
  `;
}

function closeInventoryModal() {
  const modal = document.getElementById('inventory-modal');
  if (modal) modal.classList.remove('active');
}

function saveInventoryItem(e, editId) {
  e.preventDefault();
  const name     = document.getElementById('inv-name')?.value.trim();
  const price    = parseFloat(document.getElementById('inv-price')?.value) || 0;
  const stock    = parseInt(document.getElementById('inv-stock')?.value)   || 0;
  const category = document.getElementById('inv-category')?.value || 'other';
  const desc     = document.getElementById('inv-desc')?.value.trim()  || '';
  const tags     = (document.getElementById('inv-tags')?.value || '').split(',').map(t => t.trim()).filter(Boolean);

  if (!name) { showToast('Product name is required.', 'error'); return; }

  adminInventory = loadLocal('merchInventory', []);

  if (editId) {
    const idx = adminInventory.findIndex(i => i.id == editId);
    if (idx > -1) adminInventory[idx] = { ...adminInventory[idx], name, price, stock, category, description: desc, tags };
  } else {
    adminInventory.push({
      id: Date.now(),
      name, price, stock, category,
      description: desc, tags,
      sku: 'MM-' + Date.now().toString(36).toUpperCase(),
      images: [],
      createdAt: new Date().toISOString()
    });
  }

  saveLocal('merchInventory', adminInventory);
  closeInventoryModal();
  renderInventory();
  showToast(editId ? 'Item updated!' : 'Item added!', 'success');
}

function editInventory(id) { showInventoryModal(id); }

function deleteInventory(id) {
  if (!confirm('Delete this item permanently?')) return;
  adminInventory = adminInventory.filter(i => i.id != id);
  saveLocal('merchInventory', adminInventory);
  renderInventory();
  showToast('Item deleted.', 'info');
}

/* ── Customers ── */
function renderCustomers() {
  /* brandflow.html uses 'customers-table-body', admin.html uses same */
  const tbody = document.getElementById('customers-table-body');
  if (!tbody) return;
  adminCustomers = loadLocal('adminCustomers', []);

  if (adminCustomers.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:3rem;color:#a0a0a0;">No customers yet. They will appear here after their first order.</td></tr>`;
    return;
  }

  tbody.innerHTML = adminCustomers.map(c => {
    const orderCount = adminOrders.filter(o => o.email === c.email).length;
    const totalSpent = adminOrders.filter(o => o.email === c.email && o.status !== 'cancelled')
      .reduce((s, o) => s + (o.total || 0), 0);
    return `
      <tr>
        <td><strong>${c.name || c.email}</strong></td>
        <td style="color:#a0a0a0;font-size:.85rem;">${c.email}</td>
        <td>${orderCount}</td>
        <td><strong>$${totalSpent.toFixed(2)}</strong></td>
        <td>
          <button class="action-btn" onclick="viewCustomer('${c.email}')">View Orders</button>
        </td>
      </tr>
    `;
  }).join('');
}

function viewCustomer(email) {
  const orders = adminOrders.filter(o => o.email === email);
  if (orders.length === 0) { showToast('No orders for this customer.', 'info'); return; }
  const summary = orders.map(o => `#${o.id} — ${o.item} — $${(o.total||0).toFixed(2)} — ${o.status}`).join('\n');
  alert(`Orders for ${email}:\n\n${summary}`);
}

function confirmClearData() {
  if (!confirm('⚠️ Delete ALL orders, inventory, and customer data? This cannot be undone.')) return;
  ['adminOrders', 'merchInventory', 'adminCustomers', 'merchCart'].forEach(k => localStorage.removeItem(k));
  adminOrders = []; adminInventory = []; adminCustomers = [];
  renderAll();
  showToast('Database reset successfully.', 'success');
}

/* ─── 7. ORDERS PAGE (member-facing) ─────────────────────────── */
function renderMemberOrders() {
  const tbody = document.getElementById('orders-body');
  if (!tbody) return;
  const user = getCurrentUser();
  const myOrders = user
    ? adminOrders.filter(o => o.email === user.email)
    : loadLocal('guestOrders', []);

  if (myOrders.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:3rem;color:#a0a0a0;">
      No orders yet. <a href="marketplace.html" style="color:#c47d2e;">Start shopping!</a>
    </td></tr>`;
    return;
  }

  tbody.innerHTML = myOrders.map(o => `
    <tr>
      <td>#${o.id}</td>
      <td>${o.item || '—'}</td>
      <td>${o.qty || 1}</td>
      <td>${o.location || '—'}</td>
      <td>${o.dates || '—'}</td>
      <td><span class="status ${o.status}">${o.status.toUpperCase()}</span></td>
      <td><strong>$${(o.total||0).toFixed(2)}</strong></td>
    </tr>
  `).join('');
}

/* ─── 8. DYNAMIC MARKETPLACE / FEED ──────────────────────────── */
function renderDynamicMarketplace() {
  initMarketplace(); // use the full init which merges inventory
}

function renderDynamicFeed() {
  // Dynamic feed posts already hard-coded in HTML; this just re-renders if inventory has items
  const inv = loadLocal('merchInventory', []);
  if (inv.length === 0) return;
  const grid = document.getElementById('feedGrid');
  if (!grid) return;
  inv.slice(0, 3).forEach(item => {
    const card = document.createElement('div');
    card.className = 'post-card';
    card.dataset.category = 'new';
    card.innerHTML = `
      <div class="post-image" style="background:linear-gradient(135deg,#667eea,#764ba2)">
        <div class="post-badge">✨ New</div>
      </div>
      <div class="post-content">
        <div class="post-header">
          <div class="avatar"></div>
          <div class="post-info"><h4>Brand Drop</h4><span>Just now</span></div>
          <button class="follow-btn" onclick="toggleFollow(this)">Follow</button>
        </div>
        <p class="post-description">New item available: <strong>${item.name}</strong> — $${item.price.toFixed(2)}</p>
        <div class="post-tags"><span class="tag">#new</span><span class="tag">#merch</span></div>
        <div class="post-stats">
          <span class="stat" onclick="toggleLike(this)">❤️ <span class="like-count">0</span></span>
          <span class="stat">💬 0</span><span class="stat">🔄 0</span>
          <span class="stat">🔖 Save</span>
        </div>
      </div>
    `;
    grid.prepend(card);
  });
}

/* ─── 9. BOOT ─────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  updateCartBadge();

  const page = window.location.pathname.split('/').pop() || 'index.html';

  if (page.includes('brandflow') || page.includes('admin')) {
    initAdmin();
  }
  if (page.includes('marketplace')) {
    initMarketplace();
    /* Close sell modal on overlay click */
    document.getElementById('sellModal')?.addEventListener('click', e => {
      if (e.target.id === 'sellModal') closeSellModal();
    });
  }
  if (page.includes('social-feed')) {
    renderDynamicFeed();
  }
  if (page.includes('orders') && !page.includes('brandflow') && !page.includes('admin')) {
    renderMemberOrders();
  }

  /* ── Auth: Login form ── */
  const loginForm = document.querySelector('.login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', e => {
      e.preventDefault();
      const email    = (document.getElementById('login-email')    || document.getElementById('username'))?.value.trim();
      const password = (document.getElementById('login-password') || document.getElementById('password'))?.value;
      const forcedType = document.body.dataset.userType || null; // set via data-user-type on body
      login(email, password);
    });
  }

  /* ── Auth: Signup form ── */
  const signupForm = document.querySelector('.signup-form');
  if (signupForm) {
    signupForm.addEventListener('submit', e => {
      e.preventDefault();
      const type     = document.getElementById('user-type')?.value || document.body.dataset.userType || 'member';
      const name     = (document.getElementById('fullName') || document.getElementById('brandName') || document.getElementById('signup-name'))?.value.trim();
      const email    = (document.getElementById('email')    || document.getElementById('signup-email'))?.value.trim();
      const password = (document.getElementById('password') || document.getElementById('signup-password'))?.value;
      const confirm  = (document.getElementById('confirmPassword'))?.value;
      if (password !== confirm) { showToast('Passwords do not match.', 'error'); return; }
      const user = createAccount(type, name, email, password);
      if (user) setTimeout(() => { window.location.href = type === 'brand' ? 'authbrand.html' : 'authmember.html'; }, 1200);
    });
  }

  /* ── Inventory modal close on overlay click ── */
  document.getElementById('inventory-modal')?.addEventListener('click', e => {
    if (e.target.id === 'inventory-modal') closeInventoryModal();
  });
});

/* Cross-tab inventory sync */
window.addEventListener('storage', e => {
  if (e.key === 'merchInventory') {
    adminInventory = loadLocal('merchInventory', []);
    if (document.querySelector('.product-grid')) initMarketplace();
    if (document.getElementById('inventory-table-body')) renderInventory();
  }
  if (e.key === 'adminOrders' && document.getElementById('orders-table-body')) {
    adminOrders = loadLocal('adminOrders', []);
    renderOrders();
  }
});
